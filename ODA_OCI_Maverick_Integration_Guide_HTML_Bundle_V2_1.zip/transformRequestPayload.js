const request = event.payload || {};
const extension = request.providerExtension || {};
console.log(
  'Incoming CLMI messages:',
  JSON.stringify(request.messages || [], null, 2)
);
const payload = {
  compartmentId: event.compartmentId,
  servingMode: {
    servingType: 'ON_DEMAND',
    modelId: extension.modelId || MODEL_ID
  },
  chatRequest: {
    apiFormat: 'GENERIC',
    messages: (request.messages || []).map(toOciMessage),
    isStream: Boolean(request.streamResponse),
    maxTokens: request.maxTokens,
    temperature: request.temperature,
    topP: extension.topP,
    topK: extension.topK,
    frequencyPenalty: extension.frequencyPenalty,
    presencePenalty: extension.presencePenalty,
    seed: extension.seed
  }
};
console.log(
  'Outgoing OCI Maverick native Chat payload:',
  JSON.stringify(payload, null, 2)
);
return payload;
