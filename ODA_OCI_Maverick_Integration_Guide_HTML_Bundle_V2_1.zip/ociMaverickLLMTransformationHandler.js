/**
 * ============================================================================
 * Oracle Digital Assistant - OCI Meta Llama 4 Maverick Transformation Handler
 * ============================================================================
 *
 * Author      : Martin Deh
 * Organization: Oracle
 * Created     : 2026-09-04
 * Version     : 1.8
 *
 * Copyright (c) 2026, Oracle and/or its affiliates.
 *
 * Licensed under the Universal Permissive License v 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 *
 * SAMPLE CODE:
 * This code is provided for demonstration purposes only and is provided
 * "AS IS", without warranty of any kind. It should be reviewed, tested,
 * and adapted for the intended environment before use in production.
 *
 * Description:
 *   Transforms Oracle Digital Assistant CLMI requests into OCI native
 *   Generative AI Chat requests for Meta Llama 4 Maverick, and transforms
 *   OCI responses back into CLMI.
 *
 * Provider:
 *   OCI Generative AI — Meta Llama 4 Maverick
 *
 * API Endpoint:
 *   POST https://inference.generativeai.<region>.oci.oraclecloud.com/20231130/actions/chat
 *
 * Authentication:
 *   Use OCI request-signing authentication in the ODA LLM service configuration.
 *
 * Overview of the conversion performed by this handler:
 *
 *   ODA CLMI request                         OCI native Chat request
 *   ----------------                         -----------------------
 *   messages[].role/content       ->         chatRequest.messages[].role/content[]
 *   maxTokens                      ->         chatRequest.maxTokens
 *   streamResponse                 ->         chatRequest.isStream
 *
 *   OCI native Chat response                 ODA CLMI response
 *   ------------------------                 -----------------
 *   chatResponse.choices[].message ->        candidates[].content
 *   streaming SSE message/delta      ->       responseItems[].candidates[].content
 *
 * This is intentionally a transformation-only handler. OCI authentication,
 * endpoint URL, HTTP method, and request signing are configured in the ODA
 * LLM Service, not in this JavaScript file.
 *
 * ============================================================================
 */

'use strict';

const MODEL_ID = 'meta.llama-4-maverick-17b-128e-instruct-fp8';

/**
 * Normalizes an optional value to text.
 *
 * ODA requires CLMI candidate content to be a string. Returning an empty
 * string for missing text is also important for control-only stream chunks,
 * which can legitimately contain no generated token.
 */
function toText(value) {
  return value == null ? '' : String(value);
}

/**
 * Converts one ODA Common LLM Interface message to OCI's GENERIC message
 * format. OCI represents a message body as an array of typed content parts;
 * text-only ODA prompts become one TEXT part.
 *
 * ODA roles are lower-case (system, user, assistant), while OCI's native API
 * uses upper-case enum values (SYSTEM, USER, ASSISTANT).
 */
function toOciMessage(message) {
  return {
    role: String(message.role || 'user').toUpperCase(),
    content: [{ type: 'TEXT', text: toText(message.content) }]
  };
}

/**
 * Extracts text from either an OCI native message object or a streaming delta.
 *
 * The native non-streaming form is:
 *   { content: [{ type: 'TEXT', text: '...' }] }
 *
 * OCI stream events may instead use direct strings, `text`, `content`, or a
 * `delta` / `message` wrapper. Supporting all of these avoids coupling this
 * handler to one serializer version.
 */
function textFromOciMessage(message) {
  if (!message) return '';
  if (typeof message === 'string') return message;
  if (typeof message.text === 'string') return message.text;
  const content = message.content;
  if (typeof content === 'string') return content;
  if (!Array.isArray(content)) return '';
  return content
    .filter(part => part && (part.type === 'TEXT' || typeof part.text === 'string'))
    .map(part => toText(part.text))
    .join('');
}

/**
 * Converts one parsed OCI Server-Sent Event into CLMI candidates.
 *
 * ODA calls transformResponsePayload with `responseItems` when the request
 * streamed. The batch can contain regular choice events, direct message/delta
 * events, and control events. CLMI rejects `candidates: []`, so every input
 * item produces at least one candidate; a control event gets content: ''.
 */
function candidatesFromOciStreamItem(item) {
  const source = item || {};
  const choices = ((source.chatResponse || source.inferenceResponse || source).choices || []);
  if (choices.length) {
    return choices.map(choice => ({ content: textFromOciMessage(choice.message || choice.delta) }));
  }

  // OCI native chat streaming events can contain a message/delta directly,
  // rather than a non-streaming chatResponse. ODA requires each streamed
  // response item to contain at least one candidate, including control chunks.
  const content = textFromOciMessage(source.message || source.delta || source);
  return [{ content }];
}

/**
 * Maps OCI's provider error object to ODA's documented CLMI error shape.
 *
 * `modelLengthExceeded` is especially useful: ODA can retry the invocation
 * with shortened refinement history. Preserve OCI's original message so the
 * error shown in ODA troubleshooting remains actionable.
 */
function errorPayload(payload) {
  const error = (payload && payload.error) || payload || {};
  const message = toText(error.message || error.detail || JSON.stringify(payload || {}));
  const source = `${error.code || ''} ${error.type || ''} ${message}`.toLowerCase();
  let errorCode = 'unknown';
  if (/401|403|unauthori[sz]ed|forbidden|authentication/.test(source)) {
    errorCode = 'notAuthorized';
  } else if (/context|token|length|too long|maximum.*(input|prompt)/.test(source)) {
    errorCode = 'modelLengthExceeded';
  } else if (/safety|moderation|content.*filter/.test(source)) {
    errorCode = 'requestFlagged';
  } else if (/400|invalid|bad[_ ]request|unsupported/.test(source)) {
    errorCode = 'requestInvalid';
  }
  return { errorCode, errorMessage: message };
}

module.exports = {
  metadata: {
    // This name appears in the ODA Components UI. The LLM Service must select
    // this handler for ODA to invoke the transformation methods below.
    name: 'ociMaverickLLMTransformationHandler',
    eventHandlerType: 'LlmTransformation'
  },

  handlers: {
    /**
     * Converts the ODA CLMI request into OCI's native Chat API envelope.
     *
     * event.payload is the ODA CLMI request. event.compartmentId is supplied
     * by the ODA LLM Service configuration and identifies the OCI compartment
     * in which the inference call runs.
     *
     * providerExtension is the safe escape hatch for provider-specific tuning
     * values. Example in an ODA flow:
     *   { topP: 0.9, topK: 40, frequencyPenalty: 0, seed: 42 }
     * It may also specify modelId when a dedicated endpoint/model is intended.
     */
    transformRequestPayload: async (event, context) => {
      const request = event.payload || {};
      const extension = request.providerExtension || {};

      // Helpful diagnostic logging while validating the ODA integration.
      // Consider reducing or removing full prompt logging in production.
      console.log(
        'Incoming CLMI messages:',
        JSON.stringify(request.messages || [], null, 2)
      );

      const payload = {
        compartmentId: event.compartmentId,
        servingMode: {
          servingType: 'ON_DEMAND',
          modelId: extension.modelId || MODEL_ID
        },
        chatRequest: {
          // GENERIC is OCI's chat format for non-Cohere model families such
          // as Meta Llama. Do not substitute the OpenAI API request shape at
          // this native /20231130/actions/chat endpoint.
          apiFormat: 'GENERIC',
          messages: (request.messages || []).map(toOciMessage),
          isStream: Boolean(request.streamResponse),
          maxTokens: request.maxTokens,
          temperature: request.temperature,
          topP: extension.topP,
          topK: extension.topK,
          frequencyPenalty: extension.frequencyPenalty,
          presencePenalty: extension.presencePenalty,
          seed: extension.seed
        }
      };

      // Log the actual native OCI request generated by the handler. This is
      // useful for verifying message order, role conversion, model selection,
      // compartment, and streaming/token settings during integration testing.
      console.log(
        'Outgoing OCI Maverick native Chat payload:',
        JSON.stringify(payload, null, 2)
      );

      return payload;
    },

    /**
     * Converts OCI native Chat API responses into the ODA CLMI response.
     *
     * Non-streaming OCI responses place choices in chatResponse.choices.
     * ODA's expected success format is simply:
     *   { candidates: [{ content: 'generated text' }] }
     */
    transformResponsePayload: async (event, context) => {
      const payload = event.payload || {};
      if (Array.isArray(payload.responseItems)) {
        return {
          responseItems: payload.responseItems.map(item => ({
            candidates: candidatesFromOciStreamItem(item)
          }))
        };
      }
      const choices = ((payload.chatResponse || payload).choices || []);
      return {
        candidates: choices.map(choice => ({
          content: textFromOciMessage(choice.message)
        }))
      };
    },

    /**
     * Converts OCI HTTP-error bodies into ODA CLMI errors. This handler is
     * used for OCI responses with a status code of 400 or higher.
     */
    transformErrorResponsePayload: async (event, context) => errorPayload(event.payload)
  }
};
