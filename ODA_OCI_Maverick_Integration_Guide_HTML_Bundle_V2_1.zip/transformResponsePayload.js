const payload = event.payload || {};
if (Array.isArray(payload.responseItems)) {
  return {
    responseItems: payload.responseItems.map(item => ({
      candidates: candidatesFromOciStreamItem(item)
    }))
  };
}
const choices = ((payload.chatResponse || payload).choices || []);
return {
  candidates: choices.map(choice => ({
    content: textFromOciMessage(choice.message)
  }))
};
